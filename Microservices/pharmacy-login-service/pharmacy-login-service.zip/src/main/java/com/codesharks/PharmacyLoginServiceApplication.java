package com.codesharks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PharmacyLoginServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PharmacyLoginServiceApplication.class, args);
	}
}
