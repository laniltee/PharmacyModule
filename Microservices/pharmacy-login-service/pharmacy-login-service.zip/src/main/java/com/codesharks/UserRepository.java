package com.codesharks;

import org.springframework.data.repository.CrudRepository;

/**
 * Created by Lanil Marasinghe on 21-Jun-17.
 */
public interface UserRepository  extends CrudRepository<User, String>{
}
